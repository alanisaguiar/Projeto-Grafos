/* *****************************************************************************
 * Grupo:
 * Alunos integrantes:
 *
 * Descrição: Esta classe define o tipo de dado Tour implementando uma
 * Lista Encadeada Circular e definindo métodos para permitir a implementação
 * de duas heurísticas para encontrar boas soluções para o TSP.
 **************************************************************************** */

import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class Tour {
    private class Node {
        private Point p; // valor do ponto do nó
        private Node next; // ponteiro para o próximo nó
    }

    private Node start; // primeiro nó na lista encadeada

    // cria um ciclo vazio
    public Tour() {
        start = new Node();
    }

    // cria o ciclo de 4 pontos a->b->c->d->a (para depuração)
    public Tour(Point a, Point b, Point c, Point d) {
        start = new Node();
        Node b1 = new Node();
        Node c1 = new Node();
        Node d1 = new Node();
        start.p = a;
        b1.p = b;
        c1.p = c;
        d1.p = d;
        start.next = b1;
        b1.next = c1;
        c1.next = d1;
        d1.next = start;
    }

    // retorna o número de pontos neste ciclo
    public int size() {
        if (start.p == null) {
            return 0;
        } else {
            int counter = 0;
            Node current = start;
            do {
                current = current.next;
                counter += 1;
            } while (!current.equals(start));
            return counter;
        }
    }

    // retorna o comprimento deste ciclo
    public double length() {
        if (start.p == null) {
            return 0.0;
        } else {
            double distance = 0.0;
            Node current = start;
            do {
                distance += current.p.distanceTo(current.next.p);
                current = current.next;
            } while (!current.equals(start));
            return distance;
        }
    }

    // retorna uma representação em string deste ciclo
    public String toString() {
        if (start.p == null) {
            return "";
        } else {
            Node current = start;
            StringBuilder str = new StringBuilder();
            do {
                str.append(current.p.toString() + "\n");
                current = current.next;
            } while (!current.equals(start));
            return str.toString();
        }
    }

    // desenha este ciclo na tela padrão
    public void draw() {
        if (start.p != null && start.next != null) {
            Node current = start;
            do {
                current.p.drawTo(current.next.p);
                current = current.next;
            } while (!current.equals(start));
        }
    }

     // insere p usando a heurística do vizinho mais próximo
     public void insertNearest(Point p) {
         if (start.p == null) {
             // Se o ciclo estiver vazio, insere o primeiro ponto
             start.p = p;
             start.next = start;  // A lista é circular
         } else {
             Node nearest = null;  // Nó para armazenar o ponto mais próximo
             double minDistance = Double.MAX_VALUE;  // Distância mínima

             // Percorre todos os pontos do ciclo já formado para encontrar o mais próximo
             Node current = start;
             do {
                 double dist = current.p.distanceTo(p);  // Calcula a distância até o ponto p
                 if (dist < minDistance) {  // Se for o ponto mais próximo, atualiza
                     minDistance = dist;
                     nearest = current;
                 }
                 current = current.next;  // Vai para o próximo ponto
             } while (current != start);  // Enquanto não voltar ao ponto inicial

             // Cria um novo nó para o ponto p e insere no ciclo
             Node newNode = new Node();
             newNode.p = p;
             newNode.next = nearest.next;
             nearest.next = newNode;
         }
     }

     // insere p usando a heurística do menor aumento
     public void insertSmallest(Point p) {
         if (start.p == null) {
             // Se o ciclo estiver vazio, insere o primeiro ponto
             start.p = p;
             start.next = start;  // A lista é circular
         } else {
             Node smallestIncreaseNode = null;  // Nó para armazenar a posição de menor aumento
             double smallestIncrease = Double.MAX_VALUE;  // Aumento mínimo

             // Percorre todos os pontos do ciclo para encontrar onde o aumento será o menor
             Node current = start;
             do {
                 Node next = current.next;
                 double dist1 = current.p.distanceTo(p);  // Distância entre current e p
                 double dist2 = next.p.distanceTo(p);     // Distância entre p e next
                 double increase = dist1 + dist2 - current.p.distanceTo(next.p);  // Aumento da distância

                 if (increase < smallestIncrease) {  // Se o aumento for menor, atualiza
                     smallestIncrease = increase;
                     smallestIncreaseNode = current;
                 }

                 current = current.next;  // Vai para o próximo ponto
             } while (current != start);  // Enquanto não voltar ao ponto inicial

             // Cria um novo nó para o ponto p e insere no ciclo na posição com o menor aumento
             Node newNode = new Node();
             newNode.p = p;
             newNode.next = smallestIncreaseNode.next;
             smallestIncreaseNode.next = newNode;
         }
     }

    // testa esta classe chamando todos os construtores e métodos de instância
    public static void main(String[] args) {
        // define 4 pontos, vértices de um quadrado
        Point a = new Point(1.0, 1.0);
        Point b = new Point(1.0, 4.0);
        Point c = new Point(4.0, 4.0);
        Point d = new Point(4.0, 1.0);

        // cria o ciclo a -> b -> c -> d -> a
        Tour squareTour = new Tour(a, b, c, d);

        // imprime o número de pontos na saída padrão
        int size = squareTour.size();
        StdOut.println("# de pontos = " + size);

        // imprime o comprimento do ciclo na saída padrão
        double length = squareTour.length();
        StdOut.println("Comprimento do ciclo = " + length);

        // imprime o ciclo na saída padrão
        StdOut.println(squareTour);

        StdDraw.setXscale(0, 6);
        StdDraw.setYscale(0, 6);

        Point e = new Point(5.0, 6.0);
        squareTour.insertNearest(e);
        squareTour.insertSmallest(e);
        squareTour.draw();
    }
}
